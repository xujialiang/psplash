/* GdkPixbuf RGB C-Source image dump 1-byte-run-length-encoded */

#define BAR_IMG_ROWSTRIDE (690)
#define BAR_IMG_WIDTH (230)
#define BAR_IMG_HEIGHT (28)
#define BAR_IMG_BYTES_PER_PIXEL (3) /* 3:RGB, 4:RGBA */
#define BAR_IMG_RLE_PIXEL_DATA ((uint8*) \
  "\206\0\0\0\4\17\17\17""223SSVhhk\377mmp\323mmp\4hhkSSV223\17\17\17\212" \
  "\0\0\0\2\17\17\17SSV\377mmp\333mmp\2SSV\17\17\17\207\0\0\0\1$$%\377m" \
  "mp\337mmp\1$$%\205\0\0\0\1$$%\377mmp\341mmp\1$$%\203\0\0\0\1\17\17\17" \
  "\377mmp\343mmp\1\17\17\17\202\0\0\0\1SSV\377mmp\343mmp\3SSV\0\0\0\17" \
  "\17\17\377mmp\345mmp\2\17\17\17""223\377mmp\345mmp\2""223SSV\377mmp\345" \
  "mmp\2SSVhhk\377mmp\345mmp\1hhk\377mmp\377mmp\377mmp\377mmp\377mmp\377" \
  "mmp\377mmp\377mmp\377mmp\377mmp\377mmp\377mmp\377mmp\377mmp\276mmp\1" \
  "hhk\377mmp\345mmp\2hhkSSV\377mmp\345mmp\2SSV223\377mmp\345mmp\2""223" \
  "\17\17\17\377mmp\345mmp\3\17\17\17\0\0\0SSV\377mmp\343mmp\1SSV\202\0" \
  "\0\0\1\17\17\17\377mmp\343mmp\1\17\17\17\203\0\0\0\1$$%\377mmp\341mm" \
  "p\1$$%\205\0\0\0\1$$%\377mmp\337mmp\1$$%\207\0\0\0\2\17\17\17SSV\377" \
  "mmp\333mmp\2SSV\17\17\17\212\0\0\0\4\17\17\17""223SSVhhk\377mmp\323m" \
  "mp\4hhkSSV223\17\17\17\206\0\0\0")


